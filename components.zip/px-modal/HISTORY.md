v1.3.3
==================
* added style variables for theming

v1.3.2
==================
* Update dependencies

v1.3.1
==================
* fixed id bug

v1.3.0
==================
* Gulp upgrade

v1.2.11
==================
* added codepen

v1.2.10
==================
* changed responsive behavior
* added property for background scrolling disable
* added style mixins per issue 7

v1.2.9
==================
* updated 'open modal' button styles

v1.2.8
==================
* fixed demo bugs

v1.2.7
==================
* Added property for disabling positive modal button

v1.2.6
==================
* Enabled btn--disabled

v1.2.5
==================
* updated mega demo styles and bower px-demo-snippet to ^

v1.2.4
==================
* added image to readme, removed watch, added view on github

v1.2.3
==================
* added mega demo

v1.2.2
==================
* fixed vulcanize for old demo

v1.2.1
==================
* added vulcanize to demo gh-pages

v1.2.0
==================
* Upgrade to Polymer 1.5.0

v1.1.3
==================
* added oss_notice to bower ignore

v1.1.2
==================
* added pull request test for travis and updated OSS Notice

v1.1.1
==================
* added auto github pages functionality

v1.1.0
==================
* Upgrade to Polymer 1.4.0

v1.0.6
==================
* removed documentation from README and put link to gh-pages API

v1.0.5
==================
* Added white-space normal to modal to fix gh issue that it inherits.

v1.0.4
==================
* Style fixes for readme

v1.0.3
==================
* Added README

v1.0.2
==================
* Updated License

v0.0.1
==================
* Initial release
