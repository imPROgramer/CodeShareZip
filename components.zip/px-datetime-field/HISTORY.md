v0.5.4
==================
* fixed test

v0.5.3
==================
* fixed codepen

v0.5.2
==================
* Update dependencies

v0.5.1
==================
* latest gulpfile & latest demo snippet dependency

v0.5.0
==================
* Grunt to gulp migration and style modules

v0.4.13
==================
* Fixed demo event counter (issue #3)

v0.4.11
==================
* changed moment.tz to Px.moment.tz in tests

v0.4.10
==================
* added overflow to demoContainer and removed flex__wrap from mega-demo

v0.4.9
==================
* updated mega demo styles and bower px-demo-snippet to ^

v0.4.8
==================
* Component screenshot, font reference and github links for demo update

v0.4.7
==================
* Added github link

v0.4.6
==================
* Added vulcanize

v0.4.5
==================
* Updated component discription in demo

v0.4.4
==================
* Removed # in polymer dependencies

v0.4.3
==================
* Fixed footer

v0.4.2
==================
* added apiContainer class to demo

v0.4.1
==================
* Updated to mega demo

v0.4.0
==================
* Added blockPastDates

v0.3.2
==================
* added auto github pages build

v0.3.1
==================
* Added preventNotificationOnChange

v0.3.0
==================
* Upgrade to Polymer 1.5.0

v0.2.1
==================
* Improve demo

v0.2.0
==================
* Lot of changes toward first release

v0.1.1
==================
* bump datetime common version + support allowFutureDates

v0.1.0
==================
* Upgrade to Polymer 1.4.0

v0.0.1
==================
* Initial release
